To be able to review the table and index application properties for D365FFO tables (e.g. table caching, index fields, etc.), I've created a new x++ class based on the previous AOT export in the Dynamics Performance Analyzer (step 10 in https://blogs.msdn.microsoft.com/axinthefield/dynamicsperf-2-0-installation-for-dynamics-ax/). 

This is therefore distributed with the DynamicsPerf licence that comes with the original download here:
https://github.com/pfedynamics/dynamicsperf

